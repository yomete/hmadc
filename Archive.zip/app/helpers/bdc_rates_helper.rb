module BdcRatesHelper
end
